<?php

namespace app\controllers\user;
use dektrium\user\controllers\SecurityController as UController;

class UsersController extends UController
{



}
