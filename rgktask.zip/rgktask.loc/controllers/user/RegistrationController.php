<?php

namespace app\controllers\user;
use dektrium\user\controllers\RegistrationController as RController;

class RegistrationController extends RController
{

    public function actionRegister()
    {
        return parent::actionRegister();
    }

}
