<?php

namespace app\models;

use dektrium\user\models\LoginForm as BaseLoginForm;

/**
 * LoginForm is the model behind the login form.
 */
class LoginForm extends BaseLoginForm
{

}
