<?php

namespace app\models;

use dektrium\user\models\UserSearch as BaseUserSearch;

/**
 * UserInfoSearch represents the model behind the search form about `app\models\UserInfo`.
 */
class UserSearch extends BaseUserSearch
{

}
