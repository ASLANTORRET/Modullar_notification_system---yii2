<?php

return [
    'adminEmail' => 'aslantorret@gmail.com',

    // допустимые вставки событий

    'notification_system' => [
        'class_to_attach' => ['Articles', 'User', 'Profile']
    ]
];
