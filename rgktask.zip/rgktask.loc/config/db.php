<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=notification_db',
    'username' => 'admin',
    'password' => 'admin',
    'charset' => 'utf8',
];
