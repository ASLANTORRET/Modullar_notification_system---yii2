<?php
/**
 * Created by PhpStorm.
 * User: aslan
 * Date: 28.04.2016
 * Time: 11:19
 */

$this->title = "Say Hello page";

?>

<p>Hello Guy!</p>