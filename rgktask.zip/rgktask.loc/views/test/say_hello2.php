<?php
/**
 * Created by PhpStorm.
 * User: aslan
 * Date: 28.04.2016
 * Time: 11:42
 *
 */

use yii\helpers\Html;

echo Html::encode($message);